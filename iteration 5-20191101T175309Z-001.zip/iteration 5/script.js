var b = document.getElementsByClassName("grid-item"); //The number of boxes in the grid
var hehe = document.getElementById("gcon")
console.log(b.length, "Grid items"); //Prints the number of elements with "grid-item" class to the browser console
document.getElementById("button").addEventListener("click", color);
/*while(b.length !== 3,901){
	if (b.length !== 3,901){
		hehe.appendChild(g);
		return b
		console.log(b.length, "Grid items");
	}
}*/
var non = 0

while (non < 3901){
	var g = document.createElement("div");
	g.classList.add("grid-item")
	hehe.appendChild(g);
	console.log(b.length, "b-length")
	non++
	b = document.getElementsByClassName("grid-item");
}
	

var i = 0
var i2 = 0
var buttenable = false
var raudio
var rfunc
var rimage
var alreadyreset = false
console.log("buttenable", buttenable)
var a = [
	new Audio('sounds/bep-01.mp3'),
	new Audio('sounds/bep-02.mp3'),
	new Audio('sounds/bep-03.mp3'),
	new Audio('sounds/bep-04.mp3'),
	new Audio('sounds/bep-05.mp3'),
	new Audio('sounds/bep-06.mp3'),
	new Audio('sounds/bep-07.mp3'),
	new Audio('sounds/bep-08.mp3'),
	new Audio('sounds/bep-09.mp3'),
	new Audio('sounds/bep-10.mp3'),
	new Audio('sounds/bep-11.mp3'),
	new Audio('sounds/bep-12.mp3'),
	new Audio('sounds/bep-13.mp3'),
	new Audio('sounds/bep-14.mp3'),
	new Audio('sounds/bep-15.mp3'),
	new Audio('sounds/bep-16.mp3'),
	new Audio('sounds/bep-17.mp3'),
	new Audio('sounds/bep-18.mp3'),
	new Audio('sounds/bep-19.mp3'),
	new Audio('sounds/bep-20.mp3'),
	new Audio('sounds/bep-21.mp3'),
	new Audio('sounds/bep-22.mp3'),
	new Audio('sounds/bep-23.mp3'),
	new Audio('sounds/bep-24.mp3'),
	new Audio('sounds/bep-25.mp3'),
	new Audio('sounds/bep-26.mp3'),
]
	
function boy(){
	if (buttenable == false){
		buttenable = true;
		console.log("buttenable", buttenable)
	}
	
	else if (buttenable == true){
		buttenable = false;
		console.log("buttenable", buttenable)
	}
	
	if (buttenable == true){
	rfunc = Math.floor(Math.random() * 2)
	rimage = Math.floor(Math.random() * 5)
		if(rfunc == 0){
			reset()
			color()
		}
		if(rfunc == 1){
			reset()
			reveal()
		}
	}
}

while (buttenable == false && alreadyreset == false){
	reset()
	alreadyreset = true
}


function color(){
	if (i2 !== 1){
		raudio = Math.floor(Math.random() * 26)
		if (raudio == 0){b[i].style.backgroundColor = "#FF0000";}
		else if (raudio == 1){b[i].style.backgroundColor = "#FF2200";}
		else if (raudio == 2){b[i].style.backgroundColor = "#FF4400";}
		else if (raudio == 3){b[i].style.backgroundColor = "#FF6600";}
		else if (raudio == 4){b[i].style.backgroundColor = "#FF8800";}
		else if (raudio == 5){b[i].style.backgroundColor = "#FFA300";}
		else if (raudio == 6){b[i].style.backgroundColor = "#FFBB00";}
		else if (raudio == 7){b[i].style.backgroundColor = "#FFD300";}
		else if (raudio == 8){b[i].style.backgroundColor = "#FFEA00";}
		else if (raudio == 9){b[i].style.backgroundColor = "#F7FF00";}
		else if (raudio == 10){b[i].style.backgroundColor = "#A6FF00";}
		else if (raudio == 11){b[i].style.backgroundColor = "#54FF00";}
		else if (raudio == 12){b[i].style.backgroundColor = "#03FF00";}
		else if (raudio == 13){b[i].style.backgroundColor = "#00FF3F";}
		else if (raudio == 14){b[i].style.backgroundColor = "#00FF81";}
		else if (raudio == 15){b[i].style.backgroundColor = "#00FFC1";}
		else if (raudio == 16){b[i].style.backgroundColor = "#00FBFF";}
		else if (raudio == 17){b[i].style.backgroundColor = "#00BDFF";}
		else if (raudio == 18){b[i].style.backgroundColor = "#0080FF";}
		else if (raudio == 19){b[i].style.backgroundColor = "#0042FF";}
		else if (raudio == 20){b[i].style.backgroundColor = "#0005FF";}
		else if (raudio == 21){b[i].style.backgroundColor = "#3B00FF";}
		else if (raudio == 22){b[i].style.backgroundColor = "#7B00FF";}
		else if (raudio == 23){b[i].style.backgroundColor = "#BB00FF";}
		else if (raudio == 24){b[i].style.backgroundColor = "#FA00FF";}
		else if (raudio == 25){b[i].style.backgroundColor = "#FF0092";}
		a[raudio].play()
		
		if (i < b.length){i++}
		
		if(i == b.length){
			i2 = 1
			console.log("i2", i2)
		}
		
		if (i < b.length){ 							//Delays itself after each instance before looping again
			setTimeout(color, 100);
		}
	}
	
	else if(i2 == 1){
		reset()
	}
}

function reveal(){
	if (rimage == 0){
		document.body.style.backgroundImage = 'url("images/ario.jpg")'
	}
	if (rimage == 1){
		document.body.style.backgroundImage = 'url("images/nothank.png")'
	}
	if (rimage == 2){
		document.body.style.backgroundImage = 'url("images/deletethis.png")'
	}
	if (rimage == 3){
		document.body.style.backgroundImage = 'url("images/idc.jpg")'
	}
	if (rimage == 4){
		document.body.style.backgroundImage = 'url("images/non.jpg")'
	}
	if (rimage == 5){
		document.body.style.backgroundImage = 'url("images/")'
	}
	if (rimage == 6){
		document.body.style.backgroundImage = 'url("images/)'
	}
	if (rimage == 7){
		document.body.style.backgroundImage = 'url("images/")'
	}
	
	
	
	
	if (i2 !== 1){
		raudio = Math.floor(Math.random() * 1)
		b[i].style.backgroundColor = "rgba(255,255,255,0)";
		a[raudio].play
		if (i < b.length){
			i++
		}
		
		if(i == b.length){
			i2 = 1
			console.log("i2", i2)
		}
		
		if (i < b.length){ 							//Delays itself after each instance before looping again
			setTimeout(reveal, 10);
		}
	}
}

function reset(){
	if (i2 == 1){
		for(i = 0; i < b.length; i++){
			b[i].style.backgroundColor = "rgba(255,255,255,1)";
		}
		
		if(i === b.length){
			i2 = 0
			console.log("i2", i2)
			i = 0
		}
	}
}
